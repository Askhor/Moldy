# Moldy

I needed a quick templating engine for generating translated versions of files