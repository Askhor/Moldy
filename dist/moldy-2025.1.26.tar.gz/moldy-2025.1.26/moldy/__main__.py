import moldy
moldy.command_entry_point()